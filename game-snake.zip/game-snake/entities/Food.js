import { GRID_WIDTH, GRID_HEIGHT } from '../config.js';

export class Food {
  constructor() {
    this.position = { x: 0, y: 0 };
  }

  spawn(occupied = []) {
    const occupiedSet = new Set(occupied.map((p) => `${p.x},${p.y}`));
    let x;
    let y;

    do {
      x = Phaser.Math.Between(0, GRID_WIDTH - 1);
      y = Phaser.Math.Between(0, GRID_HEIGHT - 1);
    } while (occupiedSet.has(`${x},${y}`));

    this.position = { x, y };
  }

  respawn(occupied = []) {
    this.spawn(occupied);
  }
}
