import { GRID_WIDTH, GRID_HEIGHT } from '../config.js';

export const DIRECTION = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
};

export class Snake {
  constructor(startX, startY, length = 3, initialDirection = null) {
    // choose a random initial direction when not provided
    const dirs = Object.values(DIRECTION);
    const dir = initialDirection || dirs[Math.floor(Math.random() * dirs.length)];

    this.body = [];
    // place body segments opposite to movement direction so the snake faces `dir`
    for (let i = 0; i < length; i++) {
      this.body.push({ x: startX - dir.x * i, y: startY - dir.y * i });
    }
    this.direction = dir;
    this.pendingDirection = dir;
    this.score = 0;
    this.foodsEaten = 0;
  }

  setDirection(direction) {
    const opposite =
      this.direction.x + direction.x === 0 &&
      this.direction.y + direction.y === 0;
    if (!opposite) {
      this.pendingDirection = direction;
    }
  }

  update(food) {
    this.direction = this.pendingDirection;

    const head = this.body[0];
    const newHead = {
      x: head.x + this.direction.x,
      y: head.y + this.direction.y,
    };

    const ate =
      food &&
      newHead.x === food.position.x &&
      newHead.y === food.position.y;

    if (this.checkCollision(newHead, ate)) {
      return { alive: false, ate: false };
    }

    this.body.unshift(newHead);

    if (ate) {
      this.score += 10;
      this.foodsEaten += 1;
      food.respawn(this.body);
    } else {
      this.body.pop();
    }

    return { alive: true, ate };
  }

  checkCollision(newHead, willGrow) {
    if (
      newHead.x < 0 ||
      newHead.x >= GRID_WIDTH ||
      newHead.y < 0 ||
      newHead.y >= GRID_HEIGHT
    ) {
      return true;
    }

    const bodyToCheck = willGrow ? this.body : this.body.slice(0, -1);
    return bodyToCheck.some(
      (segment) => segment.x === newHead.x && segment.y === newHead.y
    );
  }

  getHead() {
    return this.body[0];
  }
}
