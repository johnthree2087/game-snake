import { Snake } from '../entities/Snake.js';
import { Food } from '../entities/Food.js';
import { DIRECTION } from '../entities/Snake.js';
import { TILE_SIZE, GRID_WIDTH, GRID_HEIGHT, SEGMENT_SIZE, SEGMENT_RADIUS, FOOD_RADIUS } from '../config.js';

const COLORS = {
  SNAKE_HEAD: 0xff8a80,
  SNAKE_BODY: 0xd32f2f,
  FOOD: 0xff5252,
};

const INITIAL_MOVE_DELAY = 250;
const MOVE_DELAY_STEP = 15;
const MIN_MOVE_DELAY = 60;
const FOODS_PER_SPEED_UP = 5;

export const GAME_WIDTH = GRID_WIDTH * TILE_SIZE;
export const GAME_HEIGHT = GRID_HEIGHT * TILE_SIZE;

export class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
  }

  preload() {
    this.load.image('bg', 'assets/bg.jpg');
    this.load.image('head', 'assets/header.png');
    this.load.image('good', 'assets/good.png');
    this.load.image('gameover', 'assets/gameover.png');
    this.load.image('gameover-box1', 'assets/gameover-box1.png');
    this.load.image('gameover-box2', 'assets/gameover-box2.png');
    this.load.image('gameover-box3', 'assets/gameover-box3.png');
    this.load.audio('eat', 'assets/eatchips.mp3');
    this.load.audio('gameover', 'assets/gameover.mp3');
    this.load.audio('bgMusic', 'assets/bg.mp3');
    this.load.image('apple', 'assets/apple.png');
  }

  create() {
    this.bgImage = this.add.image(0, 0, 'bg').setOrigin(0);

    this.bgMusic = this.sound.add('bgMusic', {
      loop: true,
      volume: 0.5,
    });
    // background music will be started when the player begins the game

    this.isGameOver = false;
    this.started = false; // will be true after player starts
    this.moveDelay = INITIAL_MOVE_DELAY;
    this.speedLevel = 0;

    // compute canvas size and choose an integer tileSize so the logical grid fills screen
    const w = this.scale.width || this.sys.game.config.width;
    const h = this.scale.height || this.sys.game.config.height;
    // runtime tile size: integer floor of available space per grid cell
    this.tileSize = Math.max(1, Math.floor(Math.min(w / GRID_WIDTH, h / GRID_HEIGHT)));
    this.segmentSize = Math.max(1, this.tileSize - 4);
    // compute logical playable area and center offsets
    const logicalWidth = GRID_WIDTH * this.tileSize;
    const logicalHeight = GRID_HEIGHT * this.tileSize;
    this.offsetX = Math.max(0, Math.round((w - logicalWidth) / 2));
    this.offsetY = Math.max(0, Math.round((h - logicalHeight) / 2));
    // size and position background to match the playable area
    this.bgImage.setPosition(this.offsetX, this.offsetY).setDisplaySize(logicalWidth, logicalHeight);

    // update offsets on resize
    this.scale.on('resize', (gameSize) => {
      const nw = gameSize.width;
      const nh = gameSize.height;
      // recompute integer tileSize on resize
      this.tileSize = Math.max(1, Math.floor(Math.min(nw / GRID_WIDTH, nh / GRID_HEIGHT)));
      this.segmentSize = Math.max(1, this.tileSize - 4);
      const logicalW = GRID_WIDTH * this.tileSize;
      const logicalH = GRID_HEIGHT * this.tileSize;
      this.offsetX = Math.max(0, Math.round((nw - logicalW) / 2));
      this.offsetY = Math.max(0, Math.round((nh - logicalH) / 2));
      // position background to match the playable area on resize
      this.bgImage.setPosition(this.offsetX, this.offsetY).setDisplaySize(logicalW, logicalH);
      // update sizes for sprites that depend on segment size
      this.headSprite?.setDisplaySize(this.segmentSize, this.segmentSize);
      this.foodSprite?.setDisplaySize(this.segmentSize, this.segmentSize);
      // reposition HUD and sprites after resize
      this.scoreText.setPosition(this.offsetX + 8, this.offsetY + 8);
      this.drawSnake();
      this.drawFood();
    });

    this.snake = new Snake(
      Math.floor(GRID_WIDTH / 2),
      Math.floor(GRID_HEIGHT / 2)
    );
    this.food = new Food();
    this.food.spawn(this.snake.body);

    this.goodImage = this.add
      .image(this.offsetX + (GRID_WIDTH * this.tileSize) / 2, this.offsetY + (GRID_HEIGHT * this.tileSize) / 2, 'good')
      .setOrigin(0.5)
      .setScale(0)
      .setAlpha(0)
      .setDepth(10)
      .setVisible(false);

    this.gameOverImage = this.add
      .image(this.offsetX + (GRID_WIDTH * this.tileSize) / 2, this.offsetY + (GRID_HEIGHT * this.tileSize) / 2, 'gameover')
      .setOrigin(0.5)
      .setScale(0)
      .setAlpha(0)
      .setDepth(20)
      .setVisible(false);

    this.snakeBodyImages = [];
    this.headSprite = this.add.image(0, 0, 'head').setDisplaySize(this.segmentSize, this.segmentSize).setOrigin(0.5);
    this.foodSprite = this.add.image(0, 0, 'apple').setOrigin(0.5).setDisplaySize(this.segmentSize, this.segmentSize);
    this.cursors = this.input.keyboard.createCursorKeys();
    this.scoreText = this.add.text(this.offsetX + 8, this.offsetX + 8, 'Score: 0', {
      fontSize: '16px',
      fill: '#ffffff',
    });

    // pause state
    this.paused = false;

    // add a 40x40 pause button at top-right of playable area
    const pauseX = this.offsetX + logicalWidth - 8; // right padding 8px
    const pauseY = this.offsetY + 8; // top padding 8px
    this.pauseBg = this.add
      .rectangle(pauseX, pauseY, 40, 40, 0x222222, 0.7)
      .setOrigin(1, 0)
      .setStrokeStyle(2, 0xffffff, 0.12)
      .setDepth(30)
      .setInteractive({ useHandCursor: true });

    this.pauseIcon = this.add
      .text(pauseX - 20, pauseY + 20, '⏸', { fontSize: '20px', color: '#ffffff' })
      .setOrigin(0.5)
      .setDepth(31)
      .setInteractive();

    const togglePause = () => {
      // Only allow toggle when the game has started (moveTimer exists) and not game over
      if (this.isGameOver) return;
      if (!this.moveTimer) return;
      this.paused = !this.paused;
      // pause/resume timer
      try {
        this.moveTimer.paused = !!this.paused;
      } catch (e) {
        // ignore if timer doesn't support paused flag
      }
      // pause/resume music if available
      if (this.bgMusic) {
        try {
          if (this.paused) {
            this.bgMusic.pause();
          } else {
            if (this.bgMusic.isPaused) {
              this.bgMusic.resume();
            } else if (!this.bgMusic.isPlaying) {
              this.bgMusic.play();
            }
          }
        } catch (e) {
          // ignore sound control errors
        }
      }
      // update icon/visual
      this.pauseIcon.setText(this.paused ? '▶' : '⏸');
      this.pauseBg.setFillStyle(this.paused ? 0x444444 : 0x222222, 0.7);
    };

    this.pauseBg.on('pointerdown', togglePause);
    this.pauseIcon.on('pointerdown', togglePause);

    // moveTimer is created when the player actually starts the game

    this.drawSnake();
    this.drawFood();
    // If the start cover has already been removed (e.g. after a restart),
    // auto-start the game so the player doesn't need to tap again.
    if (!document.getElementById('start-cover')) {
      this.time.delayedCall(50, () => {
        if (!this.started) {
          this.startGame();
        }
      });
    }
  }

  trySpeedUp() {
    const newSpeedLevel = Math.floor(this.snake.foodsEaten / FOODS_PER_SPEED_UP);
    if (newSpeedLevel <= this.speedLevel) {
      return;
    }

    this.speedLevel = newSpeedLevel;
    this.moveDelay = Math.max(
      MIN_MOVE_DELAY,
      INITIAL_MOVE_DELAY - this.speedLevel * MOVE_DELAY_STEP
    );
    this.moveTimer.delay = this.moveDelay;
  }

  showGoodEffect() {
    if (!this.goodImage) {
      return;
    }

    this.goodImage.setVisible(true).setAlpha(0).setScale(0.1);
    this.tweens.killTweensOf(this.goodImage);

    this.tweens.add({
      targets: this.goodImage,
      alpha: 1,
      scale: 0.2,
      duration: 300,
      ease: 'Power2',
      yoyo: true,
      hold: 300,
      onComplete: () => {
        this.goodImage.setVisible(false);
      },
    });
  }

  gameOver() {
    this.isGameOver = true;
    if (this.moveTimer) {
      try {
        this.moveTimer.remove();
      } catch (e) {
        // ignore if already removed
      }
      this.moveTimer = null;
    }
    this.sound.play('gameover');

    // this.showGameOverEffect();

    // compute playable area's center
    const logicalW = GRID_WIDTH * this.tileSize;
    const logicalH = GRID_HEIGHT * this.tileSize;
    const centerX = this.offsetX + logicalW / 2;
    const centerY = this.offsetY + logicalH / 2;

    // choose variant based on score
    const sc = this.snake?.score || 0;
    let boxKey = 'gameover-box1';
    if (sc <= 30) {
      boxKey = 'gameover-box1';
    } else if (sc < 60) {
      boxKey = 'gameover-box2';
    } else {
      boxKey = 'gameover-box3';
    }

    // add a responsive game-over background: height = 1/3 of screen, width preserves aspect ratio
    const displayH = Math.max(1, Math.round(this.scale.height / 3));
    let displayW = displayH; // fallback
    try {
      const src = this.textures.get(boxKey).getSourceImage();
      const aspect = (src && src.width && src.height) ? src.width / src.height : 1;
      displayW = Math.round(displayH * aspect);
    } catch (e) {
      // if texture not available, use square fallback
      displayW = displayH;
    }

    const goBg = this.add
      .image(centerX, centerY, boxKey)
      .setOrigin(0.5)
      .setDisplaySize(displayW, displayH)
      .setDepth(12);

    // show texts on top of the background
    const title = this.add
      .text(centerX, centerY - Math.round(displayH * 0.35), 'Game Over', {
        fontSize: '32px',
        fill: '#ffd54f',
        stroke: '#000000',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(13);

    const scoreTxt = this.add
      .text(centerX, centerY - Math.round(displayH * 0.25), `Score: ${this.snake.score}`, {
        fontSize: '20px',
        fill: '#ffffff',
        stroke: '#000000',
        strokeThickness: 3,
      })
      .setOrigin(0.5)
      .setDepth(13);

    const restartButton = this.add
      .text(centerX, centerY + Math.round(displayH * 0.40), 'Restart Game', {
        fontSize: '18px',
        fill: '#ffffff',
        backgroundColor: '#2e7d32',
        padding: { x: 20, y: 10 },
      })
      .setOrigin(0.5)
      .setDepth(13)
      .setInteractive({ useHandCursor: true });

    restartButton.on('pointerover', () => {
      restartButton.setStyle({ backgroundColor: '#43a047' });
    });

    restartButton.on('pointerout', () => {
      restartButton.setStyle({ backgroundColor: '#2e7d32' });
    });

    restartButton.on('pointerdown', () => {
      this.scene.restart();
    });
  }

  showGameOverEffect() {
    if (!this.gameOverImage) {
      return;
    }

    this.gameOverImage.setVisible(true).setAlpha(0).setScale(0.1);
    this.tweens.killTweensOf(this.gameOverImage);

    this.tweens.add({
      targets: this.gameOverImage,
      alpha: 1,
      scale: 0.2,
      duration: 400,
      ease: 'Power2',
      onComplete: () => {
        this.tweens.add({
          targets: this.gameOverImage,
          alpha: 0,
          scale: 1.2,
          duration: 400,
          ease: 'Power2',
          delay: 500,
          onComplete: () => {
            this.gameOverImage.setVisible(false);
          },
        });
      },
    });
  }

  update() {
    if (this.isGameOver) {
      return;
    }

    if (Phaser.Input.Keyboard.JustDown(this.cursors.up)) {
      this.snake.setDirection(DIRECTION.UP);
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.down)) {
      this.snake.setDirection(DIRECTION.DOWN);
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.left)) {
      this.snake.setDirection(DIRECTION.LEFT);
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.right)) {
      this.snake.setDirection(DIRECTION.RIGHT);
    }
  }

  drawSnake() {
    this.snakeBodyImages.forEach((bodyImage, index) => {
      const segment = this.snake.body[index + 1];
      if (!segment) {
        bodyImage.setVisible(false);
        return;
      }

      bodyImage.setVisible(true);
      bodyImage.setPosition(
        this.offsetX + segment.x * this.tileSize + this.tileSize / 2,
        this.offsetY + segment.y * this.tileSize + this.tileSize / 2
      );
    });

    this.snake.body.slice(1).forEach((segment, index) => {
      if (!this.snakeBodyImages[index]) {
        this.snakeBodyImages[index] = this.add
          .image(-9999, -9999, 'apple')
          .setOrigin(0.5)
          .setDisplaySize(this.segmentSize, this.segmentSize);
      }
    });

    const head = this.snake.getHead();
    const headX = this.offsetX + head.x * this.tileSize + this.tileSize / 2;
    const headY = this.offsetY + head.y * this.tileSize + this.tileSize / 2;
    this.headSprite.setPosition(headX, headY);
  }

  drawFood() {
    const { x, y } = this.food.position;
    const centerX = this.offsetX + x * this.tileSize + this.tileSize / 2;
    const centerY = this.offsetY + y * this.tileSize + this.tileSize / 2;

    this.foodSprite.setPosition(centerX, centerY);
    this.foodSprite.setVisible(true);
    // initial spawn visual effect
    this.showFoodSpawnEffect?.();
  }

  startGame() {
    if (this.started) {
      return;
    }
    this.started = true;

    // start background music
    if (this.bgMusic && !this.bgMusic.isPlaying) {
      this.bgMusic.play();
    }

    // create move timer to drive snake updates
    this.moveTimer = this.time.addEvent({
      delay: this.moveDelay,
      loop: true,
      callback: () => {
        if (this.isGameOver) {
          return;
        }

        const result = this.snake.update(this.food);
        if (!result.alive) {
          this.gameOver();
          return;
        }

        if (result.ate) {
          this.sound.play('eat');
          this.trySpeedUp();
          if (this.snake.foodsEaten > 0 && this.snake.foodsEaten % 3 === 0) {
            this.showGoodEffect();
          }
        }

        this.scoreText.setText(`Score: ${this.snake.score}`);
        this.drawSnake();
        this.drawFood();
      },
    });
  }

  showFoodSpawnEffect() {
    if (!this.foodSprite) return;
    // stop any previous tweens affecting the food sprite
    this.tweens.killTweensOf(this.foodSprite);

    // flash the actual food sprite: alpha pulses at 2Hz for 1 second (2 cycles)
    this.foodSprite.setAlpha(1);
    this.tweens.add({
      targets: this.foodSprite,
      alpha: 0.35,
      duration: 250,
      yoyo: true,
      repeat: 1,
      ease: 'Sine.easeInOut',
    });
  }
}
