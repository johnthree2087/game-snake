export class StartScene extends Phaser.Scene {
  constructor() {
    super('StartScene');
  }

  preload() {
    this.load.image('cover', 'assets/cover.png');
  }

  create() {
    // cover image fills the start canvas
    const w = this.scale.width || this.sys.game.config.width;
    const h = this.scale.height || this.sys.game.config.height;
    this.cover = this.add.image(0, 0, 'cover').setOrigin(0);
    this.cover.setDisplaySize(w, h);

    this.scale.on('resize', (gameSize) => {
      const nw = gameSize.width;
      const nh = gameSize.height;
      this.cover.setDisplaySize(nw, nh);
    });

    const centerX = w / 2;
    const centerY = h - 120;

    this.startBtn = this.add
      .text(centerX, centerY, 'Tap Start Game', {
        fontSize: '20px',
        fill: '#ffffff',
        backgroundColor: 'rgba(0,0,0,0.45)',
        padding: { x: 14, y: 10 },
        align: 'center',
      })
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true })
      .setDepth(10);

    // subtle pulse tween
    this.tweens.add({
      targets: this.startBtn,
      scale: 1.06,
      duration: 800,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut',
    });

    const onStart = () => {
      // dispatch a DOM event so the main script can boot the main game
      window.dispatchEvent(new CustomEvent('phaser-start'));
    };

    this.input.on('pointerdown', onStart);
    this.startBtn.on('pointerdown', onStart);
  }
}

export default StartScene;
